const connection = require('../config/db')
const dotenv = require('dotenv').config();

async function storeProgra(request, response) {
    const params = Array(
        request.body.cpfmoto,
        request.body.destino,
        request.body.hdescarga
    )

    const query = "INSERT INTO programacao(id_user, destino, hdescarga) VALUES(?, ?, ?)";

    connection.query(query, params, (err, results) => {
        if(results) {
            response.status(200).json({
                success: true,
                message: "Sucesso!",
                data: results
            })
        } else {
            response.status(400).json({
                success: false,
                message: "Erro!",
                sql:err,
            })
        }
    })
}

async function getProgra(request, response) {


    const query = `select destino, hdescarga, id_user from programacao, tasks where programacao.id_user = tasks.id and tasks.cpf = ${request.params.cpf} order by programacao.id desc`;

    connection.query(query, (err, results) => {
        if(results) {
            response.status(200).json({
                success: true,
                message: "Programação Enviada",
                data: results
            })
        } else {
            response.status(400).json({
                success: false,
                message: "Erro ao Enviar",
                sql: err
            })
        }
    })
}

async function getUsuariosNomes(request, response) {
    let query = "select * from tasks where funcao = 'motorista'";

    connection.query(query, (err, results) => {
        console.log(err, results)
        if(results) {
            response
                .status(200)
                .json({
                    success: true,
                    data: results
                })
        }
    })
}

module.exports = {
    storeProgra,
    getProgra,
    getUsuariosNomes
}