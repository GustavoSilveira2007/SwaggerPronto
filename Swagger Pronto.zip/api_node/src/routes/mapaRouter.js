const { Router } = require('express');

const router = Router();

const {storeMapa, getMapa, deleteMapa} = require('../controller/mapaController');

/**
 * @swagger
 * /store/mapa:
 *  post:
 *    summary: Coleta as informações Nome da Localização, Latitude e Longitude
 *    responses:
 *      201:
 *        description: Salva as informações Nome da Localização escolhido pelo usuário, Latitude e Longitude no banco de dados
 *        content:
 *          application/json:
 *            schema:
 *              type: array
 *              items:
 *                type: object
 */
router.post('/store/mapa', storeMapa);

/**
 * @swagger
 * /get/mapa/:
 *  get:
 *    summary: Exibi no mapa a localização
 *    responses:
 *      200:
 *        description: Exibi no mapa a localização de acordo com a latitude e longitude escolhida pelo usuário
 *        content:
 *          application/json:
 *            schema:
 *              type: array
 *              items:
 *                type: object
 */
router.get('/get/mapa/', getMapa);

/**
 * @swagger
 * /delete/mapa/:id:
 *  delete:
 *    summary: Deleta a localização do banco de dados e consequentemente do mapa
 *    responses:
 *      200:
 *        description: Deleta a localização do banco de dados e consequentemente do mapa quando clicado no botão "Remover" na lista das localizações embaixo do mapa
 *        content:
 *          application/json:
 *            schema:
 *              type: array
 *              items:
 *                type: object
 */
router.delete('/delete/mapa/:id', deleteMapa);

module.exports = router;
    