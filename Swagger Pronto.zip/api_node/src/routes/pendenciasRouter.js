const { Router } = require('express');

const router = Router();

const {storePendencia, getPendencia} = require('../controller/pendenciasController');

/**
 * @swagger
 * /store/pendencia:
 *  post:
 *    summary: Envia as informações da pendência ao motorista
 *    responses:
 *      200:
 *        description: Salva as informações da pendência no banco de dados
 *        content:
 *          application/json:
 *            schema:
 *              type: array
 *              items:
 *                type: object
 */
router.post('/store/pendencia', storePendencia);

/**
 * @swagger
 * /get/pendencia/:cpf
 *  get:
 *    summary: Exibi as informações da pendência enviada pelo gestor
 *    responses:
 *      200:
 *        description: Exibi as informações da pendência enviada pelo gestor para o motorista específico
 *        content:
 *          application/json:
 *            schema:
 *              type: array
 *              items:
 *                type: object
 */
router.get('/get/pendencia/:cpf', getPendencia);

module.exports = router;
