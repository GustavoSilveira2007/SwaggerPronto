const { Router } = require('express');
const router = Router();

const { storeTask } = require('../controller/taskController');
const { storeLogin } = require('../controller/loginController');

/**
 * @swagger
 * /store/task:
 *  post:
 *    summary: Cria a conta do usuário
 *    responses:
 *      200:
 *        description: Coleta as informações do usuário (nome, cpf, funcao, senha)
 *        content:
 *          application/json:
 *            schema:
 *              type: array
 *              items:
 *                type: object
 */
router.post('/store/task', storeTask);

/**
 * @swagger
 * /store/login:
 *  post:
 *    summary: Acessa a conta que o usuário colocar
 *    responses:
 *      200:
 *        description: Verifica se o login que o usuário colocar existe no banco de dados e se existir entra em sua conta.
 *        content:
 *          application/json:
 *            schema:
 *              type: array
 *              items:
 *                type: object
 */
router.post('/store/login', storeLogin);

module.exports = router;




