const { Router } = require('express');

const router = Router();

const {storeProgra, getProgra, getUsuariosNomes} = require('../controller/prograController');

/**
 * @swagger
 * /store/progra:
 *  post:
 *    summary: Envia as informações da programação 
 *    responses:
 *      200:
 *        description: Salva as informações da programação enviada no banco de dados
 *        content:
 *          application/json:
 *            schema:
 *              type: array
 *              items:
 *                type: object
 */
router.post('/store/progra', storeProgra);

/**
 * @swagger
 * /get/programacao/:cpf:
 *  get:
 *    summary: Exibi as informações da programação enviada
 *    responses:
 *      200:
 *        description: Exibi as informações da programação enviada (Destino e Horário da Descarga)
 *        content:
 *          application/json:
 *            schema:
 *              type: array
 *              items:
 *                type: object
 */
router.get('/get/programacao/:cpf', getProgra);

/**
 * @swagger
 * /usuarios/nomes:
 *  get:
 *    summary: Retorna as informações para o motorista
 *    responses:
 *      200:
 *        description: Retorna as informações adicionadas pelo gestor ao motorista específico
 *        content:
 *          application/json:
 *            schema:
 *              type: array
 *              items:
 *                type: object
 */
router.get('/usuarios/nomes', getUsuariosNomes);

module.exports = router;
