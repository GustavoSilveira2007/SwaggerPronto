export let account = null;

export function setAccount(newAccount) {
  account = newAccount;
}